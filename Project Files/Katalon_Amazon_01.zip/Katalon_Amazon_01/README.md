# Katalon_Amazon_01

Amazon Project Is An Automation Testing Using The Katalon Studio Automation Testing Tools Follow These Steps:

Step 1: Create the Testplan based on the given project.

Step 2: Create the Test case & Test scenarios in Excel sheet.

Step 3: Create the Test Data for Which Scenarios in Excel sheet.

Step 4: Go to the Katalon studio tool, First create the Project and give a name based on the project.

Step5: In the Testcase folder create the test case.

Step 6: Create the Test Suite level and Test suite collection in Katalon Studio.

Step 7: Create the Test Listener for Login in Katalon studio.

Step 8: All results in The GitHub and Jenkins.

Step 9: All new updates are added to GitHub with a report from Katalon studio.

Step 10: Finally the project is 90% completed and the remaining 20% send a report via email to the Host & Username with port.

Step11: My project with the help of Katalon Studio, smart internz & Dr.T.Mamatha Madam is Training for this Software Testing Automation Testing Program Power by Smartinternz & Katalon Studio Team.
